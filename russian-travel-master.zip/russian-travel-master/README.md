# Проект 3: Путешествие по России

technologies used : grid, flexbox, adaptive design
new: different screen sizes provided
Lang: html5, css

To open: any browser (written with Chrome 88.0.4324.146 using)       
                             

View the result: https://nemenova.github.io/russian-travel/